import React from 'react';
import { Link } from 'react-router-dom';
import headerLogo from '../images/header-logo.svg'; 
const Header: React.FC = () => {
  return (
    <header className='header'>
      <img src={headerLogo} alt="logo" className="header__logo" />
      <nav className='header__nav'>
        <Link to="/">Главная</Link>
        <Link to="/login">Тарифы</Link>
        <Link to="/search">FAQ</Link>
      </nav>
      <div className='header__auth'>
    <Link to="/register">Зарегистрироваться</Link>
    <div className='divider'>.</div> 
    <button className='login-button'>Войти</button>
</div>
    </header>
  );
};

export default Header;
