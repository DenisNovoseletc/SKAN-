import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Search from './pages/Search';
import SearchResults from './pages/SearchResults';
// Стили
import './styles.css';
// Создаем компонент Main для маршрутов
const Main: React.FC = () => {
  return (
    <main className="main"> {/* Добавляем класс здесь */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/search" element={<Search />} />
        <Route path="/search-results" element={<SearchResults />} />
      </Routes>
    </main>
  );
};
const App: React.FC = () => {
  return (
    <Router>
      <Header />
      <Main /> 
      <Footer />
    </Router>
  );
};



export default App;
