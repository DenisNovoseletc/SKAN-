import React from 'react';

const Search: React.FC = () => {
  return (
    <div>
      <h2>Страница поиска</h2>
    </div>
  );
};

export default Search;