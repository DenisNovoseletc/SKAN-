import React from 'react';
import loginImage from '../images/login-image.png'; 
import '../styles/login.css';
import socialImage1 from '../images/social1.svg'; // Замените на путь к вашему изображению
import socialImage2 from '../images/social2.svg'; // Замените на путь к вашему изображению
import socialImage3 from '../images/social3.svg';
const Login: React.FC = () => {
  return (
    <div className='login__container'>
      <section className="subscription">
        <h1 className="subscription__title">Для оформления подписки на тариф, необходимо авторизоваться.</h1>
        <div className="subscription__content">
          <img className="subscription__image" src={loginImage} alt="Страница авторизации" />
          <div className="subscription__placeholder">
            <div className="auth__container">
              <div className="auth__item auth__item--login">
                <button className="auth__button auth__button--login active">Войти</button>
                <div className="auth__underline auth__underline--login active"></div>
              </div>
              <div className="auth__item auth__item--register">
                <button className="auth__button auth__button--register">Зарегистрироваться</button>
                <div className="auth__underline auth__underline--register"></div>
              </div>
            </div>

            {/* Форма авторизации */}
            <div className="subscription__form">
              <label className="subscription__label">Логин или номер телефона:</label>
              <input 
                type="text" 
                placeholder="" 
                className="subscription__input" 
              />
              <label className="subscription__label">Пароль:</label>
              <input 
                type="password" 
                placeholder="" 
                className="subscription__input" 
              />
              <button className="subscription__button">Войти</button>
              <a href='#'className='subscription__href' >Восстановить пароль</a>
               <div className="social-login" style={{ width: '308px', height: '65px', marginTop: '20px' }}>
              <p className="social-login__text">Войти через:</p>
              <div className="social-login__icons">
                <img src={socialImage1} alt="Социальная сеть 1" className="social-icon" />
                <img src={socialImage2} alt="Социальная сеть 2" className="social-icon" />
                <img src={socialImage3} alt="Социальная сеть 3" className="social-icon" />
              </div>
            </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Login;
