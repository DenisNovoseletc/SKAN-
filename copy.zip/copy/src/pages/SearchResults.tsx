import React from 'react';

const SearchResults: React.FC = () => {
  return (
    <div>
      <h2>Результаты поиска</h2>
    </div>
  );
};

export default SearchResults;