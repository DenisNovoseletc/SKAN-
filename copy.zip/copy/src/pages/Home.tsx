import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h2>Добро пожаловать на главную страницу!</h2>
    </div>
  );
};

export default Home;
